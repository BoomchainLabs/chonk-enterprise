# CHONK Enterprise Final Production Build
Includes frontend, backend, staking program, multisig upgrade authority, and deployment instructions.